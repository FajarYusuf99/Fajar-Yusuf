<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa oleh Fajar Yusuf dan 2110010064</title>
</head>
<body>
    <h1>Selamat Datang di web Fajar Yusuf Metode Row</h1>
    <?php echo "nama saya {$row->nama_mhs} dan NIM saya {$row->NIM}"; ?>
    <?= "prodi saya {$row->nama_prodi} dan kode prodi saya {$row->kode_prodi}"; ?>
</body>
</html>