<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa oleh Fajar Yusuf dan 2110010064</title>
</head>
<body>
    <h1>Selamat Datang di web Fajar Yusuf Metode Row Array</h1>
    <?php echo "nama saya {$rowarray['nama_mhs']} dan NIM saya {$rowarray['NIM']}"; ?>
    <?php echo "prodi saya {$rowarray['nama_prodi']} dan kode prodi saya {$rowarray['kode_prodi']}"; ?>
</body>
</html>