<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Hello_model extends CI_Controller
{


    public function hello_nim()
    {
        return "Hello Perkenalkan saya 2110010064";
    }

    public function hello_mvc()
    {
        return "ini menggunakan MVC buatan 2110010064";
    }
}
