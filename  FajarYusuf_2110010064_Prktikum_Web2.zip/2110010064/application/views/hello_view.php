<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hello Fajar Yusuf dan 2110010064</title>
</head>
<body>
    <h1>Selamat datang di web Fajar Yusuf</h1>
    <?php
    if (isset($mvc)) {
        echo $mvc;
    }
    ?>
</body>
</html>