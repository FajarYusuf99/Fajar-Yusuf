<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa oleh Fajar Yusuf dan 2110010064</title>
</head>
<body>
    <h1>Selamat Datang di web Fajar Yusuf Metode Result Array</h1>
    <table border="2">
        <thead>
            <tr>
                <th>NO</th>
                <th>Kode Prodi</th>
                <th>Nama Prodi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($resultarray as $row) { ?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $row['id_prodi'] ?></td>
                <td><?php echo $row['nama_prodi'] ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>