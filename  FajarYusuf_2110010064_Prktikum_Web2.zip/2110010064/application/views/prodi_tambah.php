<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Prodi oleh Fajar Yusuf dan 2110010064</title>
</head>
<body>
    <h1>Form tambah Prodi</h1>
    <form action="<?= site_url('prodi/simpan') ?>" method="post">
        <label for="id_prodi">ID Prodi</label>
        <input type="text" name="id_prodi"><br>
        <label for="nama_prodi">Nama Prodi</label>
        <input type="text" name="nama_prodi"><br>
        <input type="submit" value="Simpan">
    </form>
</body>
</html>