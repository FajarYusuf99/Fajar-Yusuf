<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa dari Fajar Yusuf dan 2110010064</title>
</head>
<body>
    <h1>Selamat Datang di web Fajar Yusuf</h1>
    <a href="<?php echo site_url('prodi/tambah') ?>">Tambah</a>
    <table border="2">
        <thead>
            <tr>
                <td>NO</td>
                <td>ID Prodi</td>
                <td>Nama Prodi</td>
                <td>Aksi</td>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($prodi as $row) { ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row->id_prodi ?></td>
                    <td><?php echo $row->nama_prodi ?></td>
                    <td>
                        <a href="<?= site_url('prodi/edit/' . $row->id_prodi) ?>">Edit</a>
                        <a href="<?= site_url('prodi/hapus/' . $row->id_prodi) ?>">Hapus</a>
                    </td>
                </tr>
                <?php } ?>
        </tbody>
    </table>
</body>
</html>